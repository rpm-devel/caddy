---
title: Markdown test 1
sitename: A Caddy website
---

## Welcome on the blog

Body

``` go
func getTrue() bool {
    return true
}
```
