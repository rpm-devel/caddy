foo.php.php/index.php
